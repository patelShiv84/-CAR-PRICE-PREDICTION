import streamlit as st
import pandas as pd
import numpy as np
import joblib

# Load trained model and column names
model = joblib.load("car_price_model.pkl")
model_columns = joblib.load("model_columns.pkl")

# Title
st.title("🚗 Car Price Prediction App")
st.markdown("This app predicts the **Selling Price** of a used car.")

# Input fields
fuel_type = st.selectbox("Fuel Type", ['Diesel', 'Petrol', 'CNG', 'LPG', 'Electric'])
seller_type = st.selectbox("Seller Type", ['Dealer', 'Individual', 'Trustmark Dealer'])
transmission_type = st.selectbox("Transmission", ['Manual', 'Automatic'])
brand = st.selectbox("Brand", ['Maruti', 'Hyundai', 'Honda', 'Toyota'])  # adjust as per dataset
model_car = st.selectbox("Model", ['Alto', 'i20', 'City', 'Innova'])      # adjust as per dataset

vehicle_age = st.slider("Vehicle Age (in years)", 0, 20, 5)
km_driven = st.number_input("Kilometers Driven", 1000, 1000000, 50000)
mileage = st.number_input("Mileage (kmpl)", 5.0, 50.0, 20.0)
engine = st.number_input("Engine Capacity (CC)", 500, 5000, 1200)
max_power = st.number_input("Max Power (bhp)", 10.0, 500.0, 70.0)
seats = st.selectbox("Number of Seats", [2, 4, 5, 6, 7, 8])

# When Predict is clicked
if st.button("Predict Price"):
    try:
        # Base dataframe
        input_data = pd.DataFrame({
            'vehicle_age': [vehicle_age],
            'km_driven': [km_driven],
            'mileage': [mileage],
            'engine': [engine],
            'max_power': [max_power],
            'seats': [seats],
            'age_km_interaction': [vehicle_age * km_driven],
            'km_driven_squared': [km_driven ** 2],
            'engine_squared': [engine ** 2],
        })

        # One-hot encoding for categorical variables
        cat_data = {
            f'fuel_type_{fuel_type}': 1,
            f'seller_type_{seller_type}': 1,
            f'transmission_type_{transmission_type}': 1,
            f'brand_{brand}': 1,
            f'model_{model_car}': 1,
        }

        for col in model_columns:
            if col not in input_data.columns:
                input_data[col] = cat_data.get(col, 0)

        # Reorder columns
        input_data = input_data[model_columns]

        st.write("✅ Input Data for Prediction:")
        st.dataframe(input_data)

        # Make prediction
        prediction = model.predict(input_data)[0]
        st.success(f"💰 Estimated Selling Price: ₹ {prediction:,.2f}")
    
    except Exception as e:
        st.error(f"Prediction failed: {e}")
